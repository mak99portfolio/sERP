<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InventoryStatusAdjustment extends Model{

    protected $guarded=['id'];

}
