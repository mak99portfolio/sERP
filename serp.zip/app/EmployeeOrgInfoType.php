<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployeeOrgInfoType extends Model
{
    //
}
