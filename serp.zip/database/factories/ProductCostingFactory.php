<?php

use Faker\Generator as Faker;

$factory->define(App\ProductCosting::class, function (Faker $faker) {
    return [
        //
    ];
});
