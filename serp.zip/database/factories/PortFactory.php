<?php

use Faker\Generator as Faker;

$factory->define(App\Port::class, function (Faker $faker) {
    return [
        //
    ];
});
