<?php

use Faker\Generator as Faker;

$factory->define(App\CommercialInvoiceTracking::class, function (Faker $faker) {
    return [
        //
    ];
});
