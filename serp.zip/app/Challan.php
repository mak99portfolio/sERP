<?php

namespace App\Model\inventory;

use Illuminate\Database\Eloquent\Model;

class Challan extends Model
{
    //
}
