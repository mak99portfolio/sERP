<?php

use Faker\Generator as Faker;

$factory->define(App\CompanyLicense::class, function (Faker $faker) {
    return [
        //
    ];
});
