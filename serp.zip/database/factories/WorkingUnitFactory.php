<?php

use Faker\Generator as Faker;

$factory->define(App\Model\inventory\WorkingUnit::class, function (Faker $faker) {
    return [
        //
    ];
});
