<?php

use Faker\Generator as Faker;

$factory->define(App\PurchaseRequisition::class, function (Faker $faker) {
    return [
        //
    ];
});
