<?php

use Faker\Generator as Faker;

$factory->define(App\UnitOfMeasurement::class, function (Faker $faker) {
    return [
        //
    ];
});
