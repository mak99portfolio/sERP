<?php

use Faker\Generator as Faker;

$factory->define(App\Model\Pocurement\CommercialInvoice::class, function (Faker $faker) {
    return [
        //
    ];
});
