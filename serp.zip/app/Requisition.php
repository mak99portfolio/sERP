<?php

namespace App\Model\inventory;

use Illuminate\Database\Eloquent\Model;

class Requisition extends Model
{
    //
}
