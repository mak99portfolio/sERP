<?php

use Faker\Generator as Faker;

$factory->define(App\Model\inventory\ReceiveItem::class, function (Faker $faker) {
    return [
        //
    ];
});
