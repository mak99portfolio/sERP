<?php

use Faker\Generator as Faker;

$factory->define(App\CompanyBank::class, function (Faker $faker) {
    return [
        //
    ];
});
