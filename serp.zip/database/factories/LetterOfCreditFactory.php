<?php

use Faker\Generator as Faker;

$factory->define(App\LetterOfCredit::class, function (Faker $faker) {
    return [
        //
    ];
});
