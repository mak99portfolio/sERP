<?php

use Faker\Generator as Faker;

$factory->define(App\ProductPattern::class, function (Faker $faker) {
    return [
        //
    ];
});
