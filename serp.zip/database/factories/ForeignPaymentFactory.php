<?php

use Faker\Generator as Faker;

$factory->define(App\ForeignPayment::class, function (Faker $faker) {
    return [
        //
    ];
});
