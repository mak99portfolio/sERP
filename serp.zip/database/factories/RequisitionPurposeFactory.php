<?php

use Faker\Generator as Faker;

$factory->define(App\RequisitionPurpose::class, function (Faker $faker) {
    return [
        //
    ];
});
