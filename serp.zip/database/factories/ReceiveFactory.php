<?php

use Faker\Generator as Faker;

$factory->define(App\Model\inventory\Receive::class, function (Faker $faker) {
    return [
        //
    ];
});
