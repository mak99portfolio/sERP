<?php

use Faker\Generator as Faker;

$factory->define(App\RequisitionType::class, function (Faker $faker) {
    return [
        //
    ];
});
