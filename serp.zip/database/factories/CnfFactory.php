<?php

use Faker\Generator as Faker;

$factory->define(App\Cnf::class, function (Faker $faker) {
    return [
        //
    ];
});
