<?php

use Faker\Generator as Faker;

$factory->define(App\InsuranceCoverNote::class, function (Faker $faker) {
    return [
        //
    ];
});
