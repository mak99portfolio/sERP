<?php

use Faker\Generator as Faker;

$factory->define(App\Model\inventory\ReceivePurchase::class, function (Faker $faker) {
    return [
        //
    ];
});
