<?php

use Faker\Generator as Faker;

$factory->define(App\Exporter::class, function (Faker $faker) {
    return [
        //
    ];
});
