<?php

use Faker\Generator as Faker;

$factory->define(App\LocalRequisition::class, function (Faker $faker) {
    return [
        //
    ];
});
