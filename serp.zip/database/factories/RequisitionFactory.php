<?php

use Faker\Generator as Faker;

$factory->define(App\Model\inventory\Requisition::class, function (Faker $faker) {
    return [
        //
    ];
});
