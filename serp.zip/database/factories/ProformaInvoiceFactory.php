<?php

use Faker\Generator as Faker;

$factory->define(App\ProformaInvoice::class, function (Faker $faker) {
    return [
        //
    ];
});
