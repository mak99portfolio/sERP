<?php

namespace App\Model\inventory;

use Illuminate\Database\Eloquent\Model;

class Issue extends Model{

	protected $guarded=['id'];

}
