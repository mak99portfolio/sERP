<?php

use Faker\Generator as Faker;

$factory->define(App\Model\inventory\ReceiveReturn::class, function (Faker $faker) {
    return [
        //
    ];
});
