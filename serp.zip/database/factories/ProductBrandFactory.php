<?php

use Faker\Generator as Faker;

$factory->define(App\ProductBrand::class, function (Faker $faker) {
    return [
        //
    ];
});
