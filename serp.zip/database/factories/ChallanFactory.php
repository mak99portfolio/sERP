<?php

use Faker\Generator as Faker;

$factory->define(App\Model\inventory\Challan::class, function (Faker $faker) {
    return [
        //
    ];
});
