<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Exporter extends Model
{
    //
}
