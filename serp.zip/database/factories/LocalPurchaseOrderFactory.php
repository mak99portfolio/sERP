<?php

use Faker\Generator as Faker;

$factory->define(App\LocalPurchaseOrder::class, function (Faker $faker) {
    return [
        //
    ];
});
