<?php

use Faker\Generator as Faker;

$factory->define(App\Model\inventory\Issue::class, function (Faker $faker) {
    return [
        //
    ];
});
