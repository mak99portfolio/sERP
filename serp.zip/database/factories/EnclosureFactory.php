<?php

use Faker\Generator as Faker;

$factory->define(App\Enclosure::class, function (Faker $faker) {
    return [
        //
    ];
});
