<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ForeignPayment extends Model
{
    //
}
