<?php

use Faker\Generator as Faker;

$factory->define(App\CostSheet::class, function (Faker $faker) {
    return [
        //
    ];
});
