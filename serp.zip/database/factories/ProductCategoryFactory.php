<?php

use Faker\Generator as Faker;
use App\User;

$factory->define(App\ProductCategory::class, function (Faker $faker) {
        return [
      
    ];
});
