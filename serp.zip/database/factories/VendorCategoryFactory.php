<?php

use Faker\Generator as Faker;

$factory->define(App\VendorCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
