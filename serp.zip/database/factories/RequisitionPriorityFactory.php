<?php

use Faker\Generator as Faker;

$factory->define(App\RequisitionPriority::class, function (Faker $faker) {
    return [
        //
    ];
});
