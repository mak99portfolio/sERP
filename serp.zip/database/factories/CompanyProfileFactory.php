<?php

use Faker\Generator as Faker;

$factory->define(App\CompanyProfile::class, function (Faker $faker) {
    return [
        //
    ];
});
